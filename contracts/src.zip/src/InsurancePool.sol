// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";

/// @title InsurancePool — Underwriter pool with bonding curve premiums
/// @notice Single-pool insurance contract for MANDATE. Underwriters stake RATE,
///         policyholders pay premiums, and claims trigger proportional payouts.
/// @dev Security: SafeERC20, ReentrancyGuard, AccessControl, Pausable.
///      Time logic uses block.timestamp (MegaETH compatible).
/// @custom:invariant totalStaked >= 0 (never negative, protected by underflow checks)
/// @custom:invariant totalShares = sum of all sharesOf[underwriter] (proportional ownership)
/// @custom:invariant premiumReserves tracked separately from totalStaked (capital segregation)
/// @custom:invariant Utilization ratio = totalCoverage / totalStaked (bonding curve input)
/// @custom:invariant Solvency ratio = (totalStaked + premiumReserves) / totalCoverage >= 120% (enforced in triggerClaim)
/// @custom:invariant Unstake requires 500s cooldown (two-step process: initiate → complete)
/// @custom:invariant Premium calculation: BASE_PREMIUM × (1 + utilization_ratio) in 10,000 bps precision
/// @custom:security ReentrancyGuard on all state-changing functions with token transfers
/// @custom:security SafeERC20 for all IERC20 operations (handles non-standard tokens)
/// @custom:security Pausable emergency stop (OPERATOR_ROLE can pause/unpause)
/// @custom:security CEI pattern enforced (Checks-Effects-Interactions)
contract InsurancePool is AccessControl, ReentrancyGuard, Pausable {
    using SafeERC20 for IERC20;

    /* ══════════════════════════════════════════════════════════════════════════════
       CONSTANTS & IMMUTABLES
       ══════════════════════════════════════════════════════════════════════════════ */

    bytes32 public constant OPERATOR_ROLE = keccak256("OPERATOR_ROLE");

    uint256 public constant UNSTAKE_COOLDOWN = 500; // PHASE_3_PLACEHOLDER (500 seconds)
    uint256 public constant BASE_PREMIUM_BPS = 500; // PHASE_3_PLACEHOLDER (5% = 500 bps)
    uint256 public constant MIN_SOLVENCY_RATIO_BPS = 12000; // PHASE_3_PLACEHOLDER (120%)

    IERC20 public immutable rateToken;

    /* ══════════════════════════════════════════════════════════════════════════════
       STATE VARIABLES
       ══════════════════════════════════════════════════════════════════════════════ */

    /// @notice Total RATE staked in the pool (underwriter capital only)
    uint256 public totalStaked;

    /// @notice Total shares issued to underwriters
    uint256 public totalShares;

    /// @notice Total active coverage across all policies
    uint256 public totalCoverage;

    /// @notice Premium reserves (separate from staked capital)
    uint256 public premiumReserves;

    /// @notice Next policy ID
    uint256 public nextPolicyId = 1;

    /// @notice Underwriter shares (proportional ownership)
    mapping(address => uint256) public sharesOf;

    /// @notice Unstake requests (two-step process)
    mapping(address => UnstakeRequest) public unstakeRequests;

    /// @notice Active policies
    mapping(uint256 => Policy) private policies;

    /* ══════════════════════════════════════════════════════════════════════════════
       STRUCTS
       ══════════════════════════════════════════════════════════════════════════════ */

    struct Policy {
        address holder;
        uint256 coverageAmount;
        uint64 expiryTimestamp; // block.timestamp
        bool claimed;
    }

    struct UnstakeRequest {
        uint256 amount;
        uint64 finalTimestamp; // block.timestamp
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       EVENTS
       ══════════════════════════════════════════════════════════════════════════════ */

    event Staked(address indexed underwriter, uint256 amount, uint256 shares);
    event UnstakeInitiated(address indexed underwriter, uint256 amount, uint64 finalTimestamp);
    event Unstaked(address indexed underwriter, uint256 amount);
    event PolicyPurchased(
        uint256 indexed policyId,
        address indexed holder,
        uint256 coverage,
        uint256 premium
    );
    event ClaimTriggered(uint256 totalPayout, uint256 claimants);

    /* ══════════════════════════════════════════════════════════════════════════════
       CONSTRUCTOR
       ══════════════════════════════════════════════════════════════════════════════ */

    /// @notice Deploy InsurancePool with RATE token reference
    /// @param _rateToken Address of RateToken contract
    constructor(address _rateToken) {
        if (_rateToken == address(0)) revert("Zero address");

        rateToken = IERC20(_rateToken);

        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       STAKING
       ══════════════════════════════════════════════════════════════════════════════ */

    /// @notice Stake RATE to become an underwriter
    /// @param amount Amount of RATE to stake
    function stake(uint256 amount) external whenNotPaused {
        if (amount == 0) revert("Zero amount");

        uint256 shares;

        if (totalShares == 0) {
            // First staker gets 1:1 shares
            shares = amount;
        } else {
            // Proportional shares: (amount / totalStaked) * totalShares
            shares = (amount * totalShares) / totalStaked;
        }

        // Effects
        totalStaked += amount;
        totalShares += shares;
        sharesOf[msg.sender] += shares;

        // Interaction (SafeERC20)
        rateToken.safeTransferFrom(msg.sender, address(this), amount);

        emit Staked(msg.sender, amount, shares);
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       UNSTAKING (TWO-STEP COOLDOWN)
       ══════════════════════════════════════════════════════════════════════════════ */

    /// @notice Initiate unstake request (step 1 of 2)
    /// @param amount Amount of RATE to unstake
    function initiateUnstake(uint256 amount) external {
        if (amount == 0) revert("Zero amount");
        if (sharesOf[msg.sender] == 0) revert("No stake");

        // Calculate shares to burn
        uint256 sharesToBurn = (amount * totalShares) / totalStaked;
        if (sharesToBurn > sharesOf[msg.sender]) revert("Insufficient shares");

        // Store unstake request
        unstakeRequests[msg.sender] = UnstakeRequest({
            amount: amount,
            finalTimestamp: uint64(block.timestamp + UNSTAKE_COOLDOWN)
        });

        emit UnstakeInitiated(msg.sender, amount, uint64(block.timestamp + UNSTAKE_COOLDOWN));
    }

    /// @notice Finalise unstake after cooldown (step 2 of 2)
    function finaliseUnstake() external nonReentrant {
        UnstakeRequest memory request = unstakeRequests[msg.sender];
        
        if (request.amount == 0) revert("No unstake request");
        if (block.timestamp < request.finalTimestamp) revert("Cooldown not expired");

        uint256 amount = request.amount;

        // Calculate shares to burn
        uint256 sharesToBurn = (amount * totalShares) / totalStaked;

        // Effects (CEI pattern)
        totalStaked -= amount;
        totalShares -= sharesToBurn;
        sharesOf[msg.sender] -= sharesToBurn;

        delete unstakeRequests[msg.sender];

        // Interaction (SafeERC20)
        rateToken.safeTransfer(msg.sender, amount);

        emit Unstaked(msg.sender, amount);
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       POLICY PURCHASE
       ══════════════════════════════════════════════════════════════════════════════ */

    /// @notice Purchase insurance policy
    /// @param coverageAmount Amount of RATE coverage
    /// @param durationSeconds Policy duration in seconds
    /// @return policyId Unique policy identifier
    function purchasePolicy(
        uint256 coverageAmount,
        uint64 durationSeconds
    ) external whenNotPaused returns (uint256 policyId) {
        if (coverageAmount == 0) revert("Zero coverage");
        if (durationSeconds == 0) revert("Zero duration");

        // Calculate premium via bonding curve
        uint256 premiumRate = getPremiumRate();
        uint256 premium = (coverageAmount * premiumRate * durationSeconds) / (365 days * 10_000);

        if (premium == 0) revert("Premium too low");

        // Store policy
        policyId = nextPolicyId++;
        policies[policyId] = Policy({
            holder: msg.sender,
            coverageAmount: coverageAmount,
            expiryTimestamp: uint64(block.timestamp + durationSeconds),
            claimed: false
        });

        // Update total coverage
        totalCoverage += coverageAmount;

        // Transfer premium to pool (SafeERC20)
        rateToken.safeTransferFrom(msg.sender, address(this), premium);

        // Add premium to reserves (not staked capital)
        premiumReserves += premium;

        emit PolicyPurchased(policyId, msg.sender, coverageAmount, premium);
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       CLAIM SETTLEMENT
       ══════════════════════════════════════════════════════════════════════════════ */

    /// @notice Trigger claim settlement (operator only)
    /// @dev Distributes RATE to all active policyholders
    function triggerClaim() external onlyRole(OPERATOR_ROLE) nonReentrant whenNotPaused {
        // Check solvency ratio
        uint256 solvencyRatio = getSolvencyRatio();
        if (solvencyRatio < MIN_SOLVENCY_RATIO_BPS) revert("Undercollateralised");

        uint256 totalPayout = 0;
        uint256 claimants = 0;

        // Identify active policies
        uint256[] memory activePolicyIds = new uint256[](nextPolicyId);
        uint256 activeCount = 0;

        for (uint256 i = 1; i < nextPolicyId; i++) {
            Policy storage policy = policies[i];
            
            if (
                !policy.claimed &&
                policy.holder != address(0) &&
                block.timestamp <= policy.expiryTimestamp
            ) {
                activePolicyIds[activeCount++] = i;
                totalPayout += policy.coverageAmount;
            }
        }

        if (totalPayout == 0) revert("No active policies");

        // Effects: Mark policies as claimed, update pool state
        for (uint256 i = 0; i < activeCount; i++) {
            policies[activePolicyIds[i]].claimed = true;
        }

        // Deduct from staked capital (underwriters bear losses)
        totalStaked -= totalPayout;
        totalCoverage -= totalPayout;
        claimants = activeCount;

        // Interactions: Distribute payouts
        for (uint256 i = 0; i < activeCount; i++) {
            Policy storage policy = policies[activePolicyIds[i]];
            rateToken.safeTransfer(policy.holder, policy.coverageAmount);
        }

        emit ClaimTriggered(totalPayout, claimants);
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       VIEW FUNCTIONS
       ══════════════════════════════════════════════════════════════════════════════ */

    /// @notice Get premium rate (bps) via bonding curve
    /// @return Premium rate in basis points (10000 = 100%)
    function getPremiumRate() public view returns (uint256) {
        if (totalStaked == 0) return BASE_PREMIUM_BPS;

        // premiumRate = BASE_PREMIUM × (1 + (totalCoverage / totalStaked))
        // Use higher precision to avoid rounding errors
        uint256 utilisationRatio = (totalCoverage * 10_000) / totalStaked;
        uint256 multiplier = 10_000 + utilisationRatio;
        return (BASE_PREMIUM_BPS * multiplier) / 10_000;
    }

    /// @notice Get solvency ratio (bps)
    /// @return Solvency ratio in basis points (10000 = 100%)
    function getSolvencyRatio() public view returns (uint256) {
        if (totalCoverage == 0) return type(uint256).max;
        uint256 totalCapital = totalStaked + premiumReserves;
        return (totalCapital * 10_000) / totalCoverage;
    }

    /// @notice Get policy details
    /// @param policyId Policy identifier
    /// @return holder Policy holder address
    /// @return coverageAmount Coverage amount
    /// @return expiryTimestamp Expiry timestamp
    /// @return claimed Whether policy has been claimed
    function getPolicy(uint256 policyId)
        external
        view
        returns (
            address holder,
            uint256 coverageAmount,
            uint64 expiryTimestamp,
            bool claimed
        )
    {
        Policy memory policy = policies[policyId];
        return (policy.holder, policy.coverageAmount, policy.expiryTimestamp, policy.claimed);
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       ADMIN FUNCTIONS
       ══════════════════════════════════════════════════════════════════════════════ */

    /// @notice Pause pool operations (emergency)
    function pause() external onlyRole(DEFAULT_ADMIN_ROLE) {
        _pause();
    }

    /// @notice Unpause pool operations
    function unpause() external onlyRole(DEFAULT_ADMIN_ROLE) {
        _unpause();
    }
}
