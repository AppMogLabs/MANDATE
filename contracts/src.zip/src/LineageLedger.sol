// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";

/// @title LineageLedger — Immutable data ingestion lineage tracking
/// @notice Tracks immutable DATA ingestion lineage. Every DATA node records a parent hash on-chain.
///         Poison nodes cost 5% reputation. Purity score (0-100) is queryable at analyst/premium tier only.
/// @dev Uses mapping-based storage for high-write efficiency. Lineage traversal is iterative (non-recursive).
///      MegaETH compatible (Chain ID 4326, block.timestamp).
contract LineageLedger is AccessControl {
    // =========================================================================
    // Roles
    // =========================================================================
    
    /// @notice PREMIUM_ROLE: Required to call queryPurityPremium()
    bytes32 public constant PREMIUM_ROLE = keccak256("PREMIUM_ROLE");
    
    // =========================================================================
    // State
    // =========================================================================
    
    /// @notice Node struct: immutable record of a data ingestion event
    struct Node {
        bytes32 nodeId;      // Unique identifier for this node
        bytes32 parentHash;  // Hash of parent node (or zero for root)
        bool isPoison;       // True if this node is poisoned
        address agent;       // Agent that ingested this node
        uint64 timestamp;    // Block timestamp when ingested
    }
    
    /// @notice Maps nodeId => Node data
    mapping(bytes32 => Node) private nodes;
    
    /// @notice Maps nodeId => parentNodeId for fast parent lookup
    /// @dev Used for efficient lineage traversal
    mapping(bytes32 => bytes32) private parentOf;
    
    /// @notice Counter for generating unique nodeIds
    uint256 private nodeCounter;
    
    // =========================================================================
    // Events
    // =========================================================================
    
    /// @notice Emitted when a new node is ingested
    event NodeIngested(
        bytes32 indexed nodeId,
        bytes32 parentHash,
        bool poisoned,
        address indexed agent
    );
    
    /// @notice Emitted when reputation is burned for poisoned nodes
    event ReputationBurned(address indexed agent, uint256 amount);
    
    // =========================================================================
    // Constructor
    // =========================================================================
    
    /// @param admin Address that receives DEFAULT_ADMIN_ROLE (can grant PREMIUM_ROLE)
    constructor(address admin) {
        require(admin != address(0), "LineageLedger: zero admin");
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
    }
    
    // =========================================================================
    // Core Functions
    // =========================================================================
    
    /// @notice Ingest a new node with optional parent hash and poison flag
    /// @param parentHash The hash of the parent node (or zero for root)
    /// @param isPoison True if this node is poisoned (5% reputation penalty)
    /// @return nodeId The unique identifier of the newly ingested node
    function ingestWithParent(bytes32 parentHash, bool isPoison) 
        external 
        returns (bytes32 nodeId)
    {
        // Generate unique nodeId
        nodeCounter++;
        nodeId = keccak256(abi.encodePacked(msg.sender, block.timestamp, nodeCounter));
        
        // Record node
        Node memory newNode = Node({
            nodeId: nodeId,
            parentHash: parentHash,
            isPoison: isPoison,
            agent: msg.sender,
            timestamp: uint64(block.timestamp)
        });
        
        nodes[nodeId] = newNode;
        
        // Map parent relationship for traversal
        // If parentHash is not zero, try to find its nodeId in the chain
        // For now, we store parentHash as-is; traversal will use this
        if (parentHash != bytes32(0)) {
            parentOf[nodeId] = parentHash;
        }
        
        // TODO: Poison penalty stub for Phase 2
        // In Phase 3, this will call: IReputationLedger(reputationLedger).burnReputation(msg.sender, 5%)
        if (isPoison) {
            // Stub: reputation burn will be implemented in Phase 3
            emit ReputationBurned(msg.sender, 0);
        }
        
        // Emit event
        emit NodeIngested(nodeId, parentHash, isPoison, msg.sender);
    }
    
    /// @notice Query purity score for a given node (premium-tier only)
    /// @dev Requires PREMIUM_ROLE. Calculates purity based on poison ratio in lineage.
    ///      Traverses up to 5 generations of ancestors.
    /// @param nodeId The node to analyze
    /// @return purityScore Score 0-100 (100 = clean, 0 = all poison)
    function queryPurityPremium(address, bytes32 nodeId) 
        external 
        view 
        onlyRole(PREMIUM_ROLE)
        returns (uint8 purityScore)
    {
        // Check minimum depth
        uint256 depth = getLineageDepth(nodeId);
        require(depth >= 5, "LineageLedger: Insufficient depth for premium query");
        
        // Traverse lineage and count poisons (max 5 generations)
        uint256 totalChecked = 0;
        uint256 poisonCount = 0;
        bytes32 currentId = nodeId;
        
        for (uint256 i = 0; i < 5; i++) {
            if (currentId == bytes32(0)) break;
            
            Node memory node = nodes[currentId];
            if (node.nodeId == bytes32(0)) break; // Node doesn't exist
            
            if (node.isPoison) {
                poisonCount++;
            }
            totalChecked++;
            
            // Move to parent
            currentId = node.parentHash;
        }
        
        // Calculate purity score: (1 - poison_ratio) * 100
        if (totalChecked == 0) {
            return 100; // No ancestors = pure
        }
        
        uint256 cleanCount = totalChecked - poisonCount;
        purityScore = uint8((cleanCount * 100) / totalChecked);
    }
    
    // =========================================================================
    // Query Functions
    // =========================================================================
    
    /// @notice Get full node data by nodeId
    /// @param nodeId The node to retrieve
    /// @return node The complete node struct (zero values if not found)
    function getNode(bytes32 nodeId) external view returns (Node memory node) {
        return nodes[nodeId];
    }
    
    /// @notice Calculate the depth (number of ancestors + 1) of a node
    /// @dev Traverses upward in the lineage chain, capped at 5 generations
    /// @param nodeId The node to analyze
    /// @return depth Number of nodes in chain including self
    function getLineageDepth(bytes32 nodeId) public view returns (uint256 depth) {
        bytes32 currentId = nodeId;
        
        // Traverse up to 5 generations
        for (uint256 i = 0; i < 5; i++) {
            if (currentId == bytes32(0)) break;
            
            Node memory node = nodes[currentId];
            if (node.nodeId == bytes32(0)) break; // Node doesn't exist
            
            depth++;
            currentId = node.parentHash;
        }
    }
    

}
