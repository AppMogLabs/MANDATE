// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";

/// @title ReputationLedger — On-chain trust scores for MANDATE agents
/// @notice Sprint 5: ERC-8004 Reputation Registry with feedback-based scoring
/// @dev Agents post feedback (0-10000 bps) for each other. Reputation = simple average.
///      Supports reputation burn (LineageLedger can penalize poison nodes) and epoch carry-over (getTopAgents).
/// @custom:invariant All reputation scores are in range [0, 10000] basis points (0-100%)
/// @custom:invariant rep.score = rep.totalScore / rep.feedbackCount (always maintains average consistency)
/// @custom:invariant feedbackHistory is append-only (never deleted or modified)
/// @custom:invariant burnReputation() maintains totalScore = score * feedbackCount after burns
/// @custom:security Feedback posting is permissionless (anyone can rate anyone except self)
/// @custom:security burnReputation() requires BURNER_ROLE via AccessControl
/// @custom:security getTopAgents() uses bubble sort (O(n²)) — safe for small arrays, consider off-chain for large datasets
contract ReputationLedger is AccessControl {
    // -------------------------------------------------------------------------
    // Constants
    // -------------------------------------------------------------------------

    uint256 public constant MAX_BPS = 10_000;

    // -------------------------------------------------------------------------
    // Roles
    // -------------------------------------------------------------------------

    /// @notice Role granted to LineageLedger (can burn reputation for poison nodes)
    bytes32 public constant BURNER_ROLE = keccak256("BURNER_ROLE");

    // -------------------------------------------------------------------------
    // Structs
    // -------------------------------------------------------------------------

    /// @notice Individual feedback record
    struct Feedback {
        address from;
        address to;
        uint256 score; // 0-10000 bps
        uint256 timestamp;
    }

    /// @notice Agent reputation data
    struct AgentReputation {
        uint256 score; // Simple average of all feedback scores (0-10000 bps)
        uint256 feedbackCount; // Total feedback received
        uint256 totalScore; // Sum of all scores (used for average calculation)
    }

    // -------------------------------------------------------------------------
    // State
    // -------------------------------------------------------------------------

    /// @notice Maps agent address => reputation data
    mapping(address => AgentReputation) private _reputations;

    /// @notice All feedback records (for transparency)
    Feedback[] public feedbackHistory;

    // -------------------------------------------------------------------------
    // Events
    // -------------------------------------------------------------------------

    /// @notice Emitted when feedback is posted
    /// @param from The address posting the feedback
    /// @param to The agent receiving the feedback
    /// @param score The feedback score (0-10000 bps)
    /// @param newAverageScore The agent's updated average reputation score
    /// @param timestamp Block timestamp when feedback was posted
    event FeedbackPosted(
        address indexed from,
        address indexed to,
        uint256 score,
        uint256 newAverageScore,
        uint256 timestamp
    );

    /// @notice Emitted when reputation is burned (reduced by percentage)
    /// @param agent The agent whose reputation was burned
    /// @param oldScore The reputation score before burn
    /// @param newScore The reputation score after burn
    /// @param bps The burn percentage in basis points (500 = 5%, 10000 = 100%)
    event ReputationBurned(address indexed agent, uint256 oldScore, uint256 newScore, uint256 bps);

    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------

    /// @notice Initializes the ReputationLedger with a designated admin
    /// @dev Grants DEFAULT_ADMIN_ROLE to admin, who can then grant BURNER_ROLE.
    ///      All agents start with 0 reputation score and 0 feedback count.
    /// @param admin Address that receives DEFAULT_ADMIN_ROLE (must not be address(0))
    /// @custom:security Admin validation prevents deployment with zero admin
    constructor(address admin) {
        require(admin != address(0), "ReputationLedger: zero admin");
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
    }

    // -------------------------------------------------------------------------
    // Core Functions
    // -------------------------------------------------------------------------

    /// @notice Post feedback for another agent
    /// @dev Anyone can post feedback. Score is 0-10000 bps (basis points).
    ///      Updates running average: newScore = (totalScore + newScore) / (count + 1).
    ///      Appends feedback to feedbackHistory for transparency.
    /// @param to Recipient agent address (cannot be msg.sender)
    /// @param score Feedback score (0-10000 bps, where 0 = terrible, 10000 = excellent)
    /// @custom:security Prevents self-rating (msg.sender != to)
    /// @custom:security Validates score <= 10000 to maintain bps invariant
    function postFeedback(address to, uint256 score) external {
        require(msg.sender != to, "ReputationLedger: cannot self-rate");
        require(score <= MAX_BPS, "ReputationLedger: score exceeds 10000 bps");

        AgentReputation storage rep = _reputations[to];

        // Update running average: newAvg = (totalScore + newScore) / (count + 1)
        rep.totalScore += score;
        rep.feedbackCount += 1;
        rep.score = rep.totalScore / rep.feedbackCount;

        // Record feedback
        feedbackHistory.push(
            Feedback({from: msg.sender, to: to, score: score, timestamp: block.timestamp})
        );

        emit FeedbackPosted(msg.sender, to, score, rep.score, block.timestamp);
    }

    /// @notice Burn reputation by percentage (used by LineageLedger for poison nodes)
    /// @dev Only callable by BURNER_ROLE. Reduces score by bps percentage.
    ///      Also reduces totalScore proportionally to maintain average integrity.
    ///      If oldScore is 0, function returns early (no-op).
    /// @param agent Target agent whose reputation is being burned
    /// @param bps Burn percentage in basis points (500 = 5%, 10000 = 100%)
    /// @custom:security Requires BURNER_ROLE via onlyRole modifier
    /// @custom:security Validates bps <= 10000 to prevent invalid burn percentages
    /// @custom:security Maintains invariant: totalScore = score * feedbackCount after burn
    function burnReputation(address agent, uint256 bps) external onlyRole(BURNER_ROLE) {
        require(bps <= MAX_BPS, "ReputationLedger: bps exceeds 10000");

        AgentReputation storage rep = _reputations[agent];
        uint256 oldScore = rep.score;

        if (oldScore == 0) {
            return; // No-op if already zero
        }

        uint256 burnAmount = (oldScore * bps) / MAX_BPS;
        uint256 newScore = oldScore - burnAmount;

        rep.score = newScore;

        // Also reduce totalScore proportionally to maintain average integrity
        if (rep.feedbackCount > 0) {
            rep.totalScore = newScore * rep.feedbackCount;
        }

        emit ReputationBurned(agent, oldScore, newScore, bps);
    }

    /// @notice Get top N% agents sorted by reputation score
    /// @dev Used for epoch carry-over (top 20% agents keep reputation across epochs).
    ///      Uses bubble sort (O(n²)) — acceptable for small arrays, consider off-chain for large datasets.
    ///      Rounds up top count: (totalCount * percentile + 99) / 100.
    /// @param agents Array of agent addresses to evaluate (can be empty)
    /// @param percentile Top percentile to return (1-100, e.g., 20 for top 20%)
    /// @return topAgents Sorted array of top agents (descending by score)
    /// @return scores Corresponding reputation scores for top agents
    /// @custom:security Validates percentile in range [1, 100]
    /// @custom:security Returns empty arrays if input agents array is empty
    function getTopAgents(address[] calldata agents, uint256 percentile)
        external
        view
        returns (address[] memory topAgents, uint256[] memory scores)
    {
        require(percentile >= 1 && percentile <= 100, "ReputationLedger: percentile must be 1-100");

        uint256 totalCount = agents.length;
        if (totalCount == 0) {
            return (new address[](0), new uint256[](0));
        }

        // Calculate top N count
        uint256 topCount = (totalCount * percentile + 99) / 100; // Round up
        if (topCount > totalCount) topCount = totalCount;

        // Copy agents and scores to memory for sorting
        address[] memory agentsCopy = new address[](totalCount);
        uint256[] memory scoresCopy = new uint256[](totalCount);

        for (uint256 i = 0; i < totalCount; i++) {
            agentsCopy[i] = agents[i];
            scoresCopy[i] = _reputations[agents[i]].score;
        }

        // Bubble sort (descending) — acceptable for small arrays
        // Production: use quicksort or off-chain sorting for large datasets
        for (uint256 i = 0; i < totalCount; i++) {
            for (uint256 j = i + 1; j < totalCount; j++) {
                if (scoresCopy[j] > scoresCopy[i]) {
                    // Swap scores
                    (scoresCopy[i], scoresCopy[j]) = (scoresCopy[j], scoresCopy[i]);
                    // Swap agents
                    (agentsCopy[i], agentsCopy[j]) = (agentsCopy[j], agentsCopy[i]);
                }
            }
        }

        // Return top N
        topAgents = new address[](topCount);
        scores = new uint256[](topCount);

        for (uint256 i = 0; i < topCount; i++) {
            topAgents[i] = agentsCopy[i];
            scores[i] = scoresCopy[i];
        }
    }

    // -------------------------------------------------------------------------
    // ERC-8004 Compliance (View Functions)
    // -------------------------------------------------------------------------

    /// @notice Get reputation score for an agent
    /// @dev Returns 0 if agent has never received feedback.
    /// @param agent Agent address to query
    /// @return score Reputation score (0-10000 bps, 0 if no feedback)
    function getReputation(address agent) external view returns (uint256 score) {
        return _reputations[agent].score;
    }

    /// @notice Get feedback count for an agent
    /// @dev Returns 0 if agent has never received feedback.
    /// @param agent Agent address to query
    /// @return count Total feedback received (0 if no feedback)
    function getFeedbackCount(address agent) external view returns (uint256 count) {
        return _reputations[agent].feedbackCount;
    }

    /// @notice Check if agent has received any feedback
    /// @dev Returns true only if feedbackCount > 0.
    /// @param agent Agent address to query
    /// @return has True if agent has reputation data (at least one feedback)
    function hasReputation(address agent) external view returns (bool has) {
        return _reputations[agent].feedbackCount > 0;
    }

    /// @notice Get total number of feedback records across all agents
    /// @dev Returns length of feedbackHistory array.
    /// @return count Total feedback entries in the ledger
    function getTotalFeedbackCount() external view returns (uint256 count) {
        return feedbackHistory.length;
    }

    /// @notice Get specific feedback record by index
    /// @dev Reverts if index is out of bounds.
    /// @param index Feedback index (0-based)
    /// @return feedback Feedback struct containing from, to, score, timestamp
    function getFeedback(uint256 index) external view returns (Feedback memory feedback) {
        require(index < feedbackHistory.length, "ReputationLedger: index out of bounds");
        return feedbackHistory[index];
    }
}
